<?php

    require "../php/connection.php";
    session_start();
    if(!isset($_SESSION['login_role'])){
            echo "<script language=javascript>document.location.href='login.php'</script>";
    }

    if(isset($_SESSION['login_role'])){
        if($_SESSION['login_role'] != 'Karyawan')
            echo "<script language=javascript>document.location.href='login.php'</script>";
    }


    $id = $_SESSION['id_customer'];
    $id_kontak = "";
    $nama = "";
    $deskripsi = "";
    $no_hp = "";
	 $email = "";
    $strQuery = "SELECT id_layananperawatan, nama_layananperawatan, kategori_layanan_perawatan, deskripsi, harga, gambar FROM layanan_perawatan";
    $query = mysqli_query($connection, $strQuery);
    if($query){
        $result = mysqli_fetch_array($query, MYSQLI_ASSOC);
        $id_layananperawatan = $result['id_layananperawatan'];
            $nama_layananperawatan = $result['nama_layananperawatan'];
              $kategori_layanan_perawatan = $result['kategori_layanan_perawatan'];
            $deskripsi = $result['deskripsi']; 
            $harga = $result['harga'];
              $gambar = $result['gambar'];
        $login_id = $result['login_id'];
        $username = $result['login_username'];
        $password = $result['login_password'];
    }
       if(isset($_GET['id_layananperawatan'])) {
        $id_layananperawatan = $_GET['id_layananperawatan'];
        $kode = "";
        $strQuery = "SELECT id_layananperawatan, nama_layananperawatan, kategori_layanan_perawatan, deskripsi, harga, gambar FROM layanan_perawatan WHERE id_layananperawatan = '$id_layananperawatan'";
        $query = mysqli_query($connection, $strQuery);
        if($query){
            $result = mysqli_fetch_array($query, MYSQLI_ASSOC);
            $id_layananperawatan = $result['id_layananperawatan'];
            $nama_layananperawatan = $result['nama_layananperawatan'];
            $kategori_layanan_perawatan = $result['kategori_layanan_perawatan'];
            $deskripsi = $result['deskripsi']; 
            $harga = $result['harga'];
              $gambar = $result['gambar'];
        }
    }
 
?>
   
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Edit Layanan & Perawatan</title>
  <!-- Favicon -->
  <link rel="icon" href="assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Argon CSS -->
  <link rel="stylesheet" href="assets/css/argon.css?v=1.2.0" type="text/css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>
  <!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
             <h1>MARIA STUDIO <br>BEAUTY</h1>
        </a>
      </div><br>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
 
                 <li class="nav-item">
              <a class="nav-link" href="index.php">
                <i class="ni ni-money-coins"></i>
                <span class="nav-link-text">Jasa Layanan & Perawatan</span>
              </a>
            </li> 
			<li class="nav-item">
              <a class="nav-link" href="data_konsumen.php">
                <i class="ni ni-circle-08"></i>
                <span class="nav-link-text">Data Konsumen</span>
              </a>
            </li>  
                		<li class="nav-item">
              <a class="nav-link" href="laporan.php">
                <i class="ni ni-single-copy-04"></i>
                <span class="nav-link-text">Laporan</span>
              </a>
            </li> 
          <!-- Divider -->
        
        </div>
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          
            <h6 class="h2 text-white d-inline-block mb-0">Edit Layanan & Perawatan</h6>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
             
                </div>
              </div>
            </li>
            <li class="nav-item d-sm-none">
              
              
            </li>
            <li class="nav-item dropdown">
            
              <div class="dropdown-menu dropdown-menu-xl  dropdown-menu-right  py-0 overflow-hidden">
                <!-- Dropdown header -->
                <div class="px-3 py-3">
                
                </div>
                <!-- List group -->
                <div class="list-group list-group-flush">
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="assets/img/theme/team-1.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>2 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="assets/img/theme/team-2.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>3 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="../assets/img/theme/team-3.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>5 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Your posts have been liked a lot.</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="../assets/img/theme/team-4.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>2 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="../assets/img/theme/team-5.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>3 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
                      </div>
                    </div>
                  </a>
                </div>
                <!-- View all -->
                <a href="#!" class="dropdown-item text-center text-primary font-weight-bold py-3">View all</a>
              </div>
            </li>
            <li class="nav-item dropdown">
            
              <div class="dropdown-menu dropdown-menu-lg dropdown-menu-dark bg-default  dropdown-menu-right ">
                <div class="row shortcuts px-4">
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-red">
                      <i class="ni ni-calendar-grid-58"></i>
                    </span>
                    <small>Calendar</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-orange">
                      <i class="ni ni-email-83"></i>
                    </span>
                    <small>Email</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-info">
                      <i class="ni ni-credit-card"></i>
                    </span>
                    <small>Payments</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-green">
                      <i class="ni ni-books"></i>
                    </span>
                    <small>Reports</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-purple">
                      <i class="ni ni-pin-3"></i>
                    </span>
                    <small>Maps</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-yellow">
                      <i class="ni ni-basket"></i>
                    </span>
                    <small>Shop</small>
                  </a>
                </div>
              </div>
            </li>
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                    <img alt="Image placeholder" src="../images/logo.png">
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $_SESSION['nama_lengkap'];?></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
           
                       
                <div class="dropdown-divider"></div>
                      <a href="index.php" class="dropdown-item">
                  <i class="ni ni-money-coins"></i>
                  <span>Jasa Layanan & Perawatan</span>
                </a>
                <a href="data_konsumen.php" class="dropdown-item">
                  <i class="ni ni-circle-08"></i>
                  <span>Data Konsumen</span>
                </a>
                  <a href="laporan.php" class="dropdown-item">
                  <i class="ni ni-single-copy-04"></i>
                  <span>Laporan</span>
                </a>
                <a href="../php/logout.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Header -->
    <!-- Page content -->
  
        <div class="col-xl-12 order-xl-1">
          <div class="card">
            <div class="card-header">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">EDIT DATA LAYANAN & PERAWATAN</h3>
                </div>
                <div class="col-4 text-right">
                 
                </div>
              </div>
            </div><br>
          <div class="container">

   <div class="container">
 <form method="POST" action="php/editlayanan_proses.php" enctype="multipart/form-data">

    <div class="form-group">
      <label for="alamat">Masukan Layanan & Perawatan:</label>
      <input type="text" name="nama_layananperawatan" class="form-control" id="nama" value="<?php echo $nama_layananperawatan;?>">
    </div>
     <div class="form-group">
      <label for="alamat">Kategori Layanan & Perawatan</label>
      <input type="text" name="kategori_layanan_perawatan" class="form-control"  value="<?php echo $kategori_layanan_perawatan;?>">
   
     <div class="form-group">
      <label for="alamat">Deskripsi</label>
      <input type="text" name="deskripsi" class="form-control" id="email" value="<?php echo $deskripsi;?>">
      
    </div>
	   <div class="form-group">
      <label for="alamat">Harga:</label>
      <input type="text" name="harga" class="form-control" id="email" value="<?php echo $harga;?>">
      
       <div class="form-group">
                                                        <label>Gambar</label>
                                                        <input type="file" accept="image/*" onchange="preview_imagee(event)" class="form-control border-input" name="gambar" /><br>
														<img 
														src="../admin/gambar_layananperawatan/<?php echo $gambar?>" 
														id="preview_image"
														style="width:200px; height:200px">
                                                </div>
    </div>
     <input type="hidden" name="id_layananperawatan" value="<?php echo "$id_layananperawatan";?>"/>
    <center><button type="submit" class="btn btn-primary">Ubah Data</button></center>
    
    
    <br>
  </form>
</div>
</div>
  </div>  
      <!-- Footer -->
      <footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-12">
            <div class="copyright text-center  text-lg-center  text-muted">
             <center> &copy; 2021 <a href="" class="font-weight-bold ml-" target="_blank">Maria Studio Beauty</a></center>
            </div>
          </div>
         
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
  <script type="text/javascript">
		function  preview_imagee(event){
			var reader = new FileReader();
			reader.onload = function()
			{
				var output = document.getElementById('preview_image');
				output.src = reader.result;
			}
			reader.readAsDataURL(event.target.files[0]);
		}
		</script>
</body>

</html>