<?php
error_reporting(0);
    require "php/connection.php";
    session_start();
    if(!isset($_SESSION['login_role'])){
            echo "<script language=javascript>document.location.href='login.php'</script>";
    }

    if(isset($_SESSION['login_role'])){
        if($_SESSION['login_role'] != 'Karyawan')
            echo "<script language=javascript>document.location.href='login.php'</script>";
    }
 
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Booking</title>
  <!-- Favicon -->
  <link rel="icon" href="assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Argon CSS -->
  <link rel="stylesheet" href="assets/css/argon.css?v=1.2.0" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<body>
  <!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
             <h1>MARIA STUDIO <br>BEAUTY</h1>
        </a>
      </div><br>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">

                 <li class="nav-item">
              <a class="nav-link" href="index.php">
                <i class="ni ni-money-coins"></i>
                <span class="nav-link-text">Jasa Perawatan & Kecantikan</span>
              </a>
            </li> 
			<li class="nav-item">
              <a class="nav-link" href="data_konsumen.php">
                <i class="ni ni-circle-08"></i>
                <span class="nav-link-text">Data Konsumen</span>
              </a>
            </li>  
                		<li class="nav-item">
              <a class="nav-link" href="laporan.php">
                <i class="ni ni-single-copy-04"></i>
                <span class="nav-link-text">Laporan</span>
              </a>
            </li> 
          <!-- Divider -->
        
        </div>
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          
            <h6 class="h2 text-white d-inline-block mb-0">Booking Layanan & Perawatan</h6>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </div>
            </li>
            <li class="nav-item d-sm-none">
              
                <i class="ni ni-zoom-split-in"></i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ni ni-bell-55"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-xl  dropdown-menu-right  py-0 overflow-hidden">
                <!-- Dropdown header -->
                <div class="px-3 py-3">
                
                </div>
                <!-- List group -->
                <div class="list-group list-group-flush">
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="assets/img/theme/team-1.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>2 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="assets/img/theme/team-2.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>3 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="../assets/img/theme/team-3.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>5 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Your posts have been liked a lot.</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="../assets/img/theme/team-4.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>2 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="../assets/img/theme/team-5.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>3 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
                      </div>
                    </div>
                  </a>
                </div>
                <!-- View all -->
                <a href="#!" class="dropdown-item text-center text-primary font-weight-bold py-3">View all</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ni ni-ungroup"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-lg dropdown-menu-dark bg-default  dropdown-menu-right ">
                <div class="row shortcuts px-4">
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-red">
                      <i class="ni ni-calendar-grid-58"></i>
                    </span>
                    <small>Calendar</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-orange">
                      <i class="ni ni-email-83"></i>
                    </span>
                    <small>Email</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-info">
                      <i class="ni ni-credit-card"></i>
                    </span>
                    <small>Payments</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-green">
                      <i class="ni ni-books"></i>
                    </span>
                    <small>Reports</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-purple">
                      <i class="ni ni-pin-3"></i>
                    </span>
                    <small>Maps</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-yellow">
                      <i class="ni ni-basket"></i>
                    </span>
                    <small>Shop</small>
                  </a>
                </div>
              </div>
            </li>
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                    <img alt="Image placeholder" src="../images/logo.png">
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $_SESSION['nama_lengkap'];?></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
               
                       
                <div class="dropdown-divider"></div>
                   <a href="index.php" class="dropdown-item">
                  <i class="ni ni-money-coins"></i>
                  <span>Jasa Layanan & Perawatan</span>
                </a>
                <a href="data_konsumen.php" class="dropdown-item">
                  <i class="ni ni-circle-08"></i>
                  <span>Data Konsumen</span>
                </a>
                  <a href="laporan.php" class="dropdown-item">
                  <i class="ni ni-single-copy-04"></i>
                  <span>Laporan</span>
                </a>
                <a href="../php/logout.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Header -->
    <!-- Header -->
    <div class="header bg-white pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
          
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
               
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
              <!--<a href="tambah_data_mitra.php" class="btn btn-sm btn-neutral">Tambah Data</a> -->
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--8">
      <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
            
       
             
		
            </div>
            <!-- Light table -->
            <div class="content table-responsive table-full-width">
                                        <table class="table table-striped" >
                                            <thead>
										
												<th>Layanan & Perawatan</th>
                                                <th>Nama Pelanggan</th>
												<th>Tanggal Booking</th>  
												<th>Bayar Booking</th> 
												<th>Status Booking</th> 
												<th>Status Bayar</th>   
                                                <th>Action</th>
                                            </thead>
                                            <tbody>
               <?php
  // Load file koneksi.php
  include "php/connection.php";
 
  $query = "SELECT * FROM booking INNER JOIN layanan_perawatan	ON booking.id_layananperawatan = layanan_perawatan.id_layananperawatan INNER JOIN registrasi ON booking.id_customer = registrasi.id_customer INNER JOIN detail_booking ON booking.booking_id = detail_booking.booking_id"; // Query untuk menampilkan semua data siswa
  $query2 = "SELECT booking_id, booking_status FROM booking ORDER BY booking_id ASC"; // Query untuk menampilkan semua data siswa
 
  $sql = mysqli_query($connection, $query); // Eksekusi/Jalankan query dari variabel $query
 
  while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
    echo "<tr>";
    echo "<td>".$data['nama_layananperawatan']."</td>";
	echo "<td>".$data['nama_lengkap']."</td>";
		echo "<td>".$data['tanggal']."</td>";
			   echo "<td><img src='../pelanggan/php/gambar/".$data['gambar']."' width='150' height='100px'></td>";
	echo "<td>".$data['booking_status']."</td>";
	echo "<td>".$data['status_bayar']."</td>";
   echo "<td><a href='cetak.php?id_customer=".$data['id_customer']."' >Cetak </a> | <a href=# data-toggle=modal data-target=#edit$i>Ubah Status</a> |  <a href=# data-toggle=modal data-target=#approve$i>Approve Pembayaran</a> </td>";
   
  
    echo "</tr>";
  
  ?>
   <!--Modal Pembayaran -->
                                                    <div class="modal fade " id="approve<?php echo $i;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                        <div class="modal-dialog" role="document">
                                                            <form method="POST" action="php/pembayaran_proses.php">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                      
                                                                      <center>  <h4 class="modal-title" id="myModalLabel">Approve Pembayaran</h4></center>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="form-group">
                                                                          
                                                                            <select class="form-control border-input" name="status_bayar">
                                                                                <option value="Sudah Bayar">Sudah Bayar</option>
                                                                               
                                                                            </select>
                                                                        </div>
                                                                    </div>
																
                                                                    <div class="modal-footer">
                                                                        <input type="hidden" name="booking_id" value="<?php echo "$data[booking_id]";?>" />
                                                                        <input type="submit" value="Submit" class="btn btn-info btn-fill"/>
                                                                        <button type="button" class="btn btn-default btn-fill" data-dismiss="modal">Cancel</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                    <!-- End Modal -->
  
  
  
 <!--Modal Edit -->
                                                    <div class="modal fade " id="edit<?php echo $i;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                        <div class="modal-dialog" role="document">
                                                            <form method="POST" action="php/booking_edit_proses.php">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                      
                                                                      <center>  <h4 class="modal-title" id="myModalLabel">Status Booking</h4></center>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="form-group">
                                                                          
                                                                            <select class="form-control border-input" name="booking_status">
                                                                                <option value="Menunggu" <?php if($data['booking_status'] == 'Menunggu') echo "selected"?>>Menunggu</option>
                                                                                <option value="Sudah Selesai" <?php if($data['booking_status'] == 'Sudah Selesai') echo "selected"?>>Sudah Selesai</option>
                                                                                <option value="DiBatalkan" <?php if($data['booking_status'] == 'DiBatalkan') echo "selected"?>>DiBatalkan</option>
																				  <option value="Layanan Dan Perawatan Sudah Penuh" <?php if($data['booking_status'] == 'Layanan Dan Perawatan Sudah Penuh') echo "selected"?>>Layanan Dan Perawatan Sudah Penuh</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
																
                                                                    <div class="modal-footer">
                                                                        <input type="hidden" name="booking_id" value="<?php echo "$data[booking_id]";?>" />
                                                                        <input type="submit" value="Submit" class="btn btn-info btn-fill"/>
                                                                        <button type="button" class="btn btn-default btn-fill" data-dismiss="modal">Cancel</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                    <!-- End Modal -->
            </div>
			  <?php
                                                        $i++;
                                                    }
                                                ?>
                </tbody>
              </table>

          </div>

   

   
  </div>

      <br>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
</body>

</html>
 <script>
            <?php
            for($j= 0 ; $j <= $i; $j++){
        ?>
            $('#delete<?php echo $j;?>').appendTo("body")
            <?php
            }
        ?>
            $('#search').appendTo("body")
        </script>
		